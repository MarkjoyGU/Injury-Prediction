# Census Income Data Set

Data downloaded from [UCI Machine Learning Repository- Census Income](http://archive.ics.uci.edu/ml/datasets/Census+Income).

## Data Set Information

Extraction was done by Barry Becker from the 1994 Census database. A set of reasonably clean records was extracted using the following conditions: ((AAGE>16) && (AGI>100) && (AFNLWGT>1)&& (HRSWK>0))

Prediction task is to determine whether a person makes over 50K a year.
