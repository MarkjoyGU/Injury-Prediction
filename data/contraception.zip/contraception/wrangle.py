#!/usr/bin/env python
"""
This file creates the meta.json and pandas dataset.csv files from the
dataset.txt file that was downloaded from the UCI machine learning repo.
"""

import os
import json
import pandas as pd

DIRNAME   = os.path.dirname(__file__)
DATAPATH  = os.path.join(DIRNAME, "cmc.txt")
OUTPATH   = os.path.join(DIRNAME, "dataset.csv")

FEATURES  = [
    "wife_age",
    "wife_education",
    "husband_education",
    "number_births",
    "wife_religion",
    "wife_working",
    "husband_occupation",
    "sol_living",
    "media_exposure",
    "method_used"
]

LABEL_MAP = {
    1: "No-use",
    2: "Long-term",
    3: "Short-term",
}

if __name__ == "__main__":
    df = pd.read_csv(DATAPATH, delimiter='\t', header=None, names=FEATURES)
    for k,v in LABEL_MAP.items():
        df.ix[df.method_used == k, 'method_used'] = v
    df.to_csv(OUTPATH, index=False)

    print "Wrote dataset of %i instances and %i attributes to %s" % (df.shape + (OUTPATH,))

    with open('meta.json', 'w') as f:
        meta = {'feature_names': FEATURES, 'target_names': LABEL_MAP}
        json.dump(meta, f, indent=4)
